const {CloudBillingClient} = require('@google-cloud/billing');
const {ProjectsClient} = require('@google-cloud/resource-manager');

const PROJECT_ID = process.env.GCP_PROJECT || process.env.GOOGLE_CLOUD_PROJECT;
const PROJECT_NAME = 'projects/' + PROJECT_ID;

exports.stopBilling = async (pubsubEvent, context) => {
  const pubsubData = JSON.parse(
    Buffer.from(pubsubEvent.data, 'base64').toString()
  );

  console.log('Budget notification received:', JSON.stringify(pubsubData));

  // Check if we've exceeded the budget
  if (pubsubData.costAmount <= pubsubData.budgetAmount) {
    console.log('Current cost (' + pubsubData.costAmount + ') is within budget (' + pubsubData.budgetAmount + '). No action needed.');
    return;
  }

  console.log('Cost (' + pubsubData.costAmount + ') exceeds budget (' + pubsubData.budgetAmount + '). Disabling billing...');

  // Disable billing
  const billingClient = new CloudBillingClient();
  const [billingInfo] = await billingClient.getProjectBillingInfo({
    name: PROJECT_NAME,
  });

  if (billingInfo.billingEnabled) {
    console.log('Billing is currently enabled. Disabling...');
    await billingClient.updateProjectBillingInfo({
      name: PROJECT_NAME,
      projectBillingInfo: {
        billingAccountName: '', // Empty string disables billing
      },
    });
    console.log('Billing has been disabled for project:', PROJECT_ID);
  } else {
    console.log('Billing is already disabled.');
  }
};
